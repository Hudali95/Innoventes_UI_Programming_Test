import React from 'react';
import Occupencies from './components/roomSelect'
import { FaBeer } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css'


import './App.css';

function App() {
  return (
    < >
      <Occupencies/>
      <FaBeer/>
    </>
  );
}

export default App;
