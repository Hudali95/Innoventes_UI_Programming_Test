import React, { Component } from 'react'
import { Container, Col, Row, Button } from 'react-bootstrap'
import { FaUserFriends, FaPlusCircle, FaMinusCircle, FaBed, FaUserAlt, FaChild } from 'react-icons/fa'

export default class roomSelect extends Component {
    constructor(props) {
        super(props);
        this.state = {
            noRooms: 1,
            noChild: 0,
            noAdults: 2
        };
    }

    handleClick = (e) => {
        switch (e.target.id) {
            case 'iRoom':
                if(this.state.noRooms != 5){
                    // if(this.state.noChild == 0 && (this.state.noAdults+this.state.noChild) != this.state.noRooms ){
                    //     this.setState({
                    //         noRooms: this.state.noRooms + 1,
                    //         noAdults: this.state.noRooms + 1
                    //     })  
                    // }else{
                        this.setState({
                            noRooms: this.state.noRooms + 1,
                            // noAdults: (this.state.noRooms + 1) * 2
                        })
                       
                        if((this.state.noAdults+this.state.noChild) < this.state.noRooms+1){
                            this.setState({
                            noAdults: this.state.noRooms + 1,
                            noChild: 0
                        })
                        }
                    // }
              
                }
               
                break;
            case 'dRoom':
                if (this.state.noRooms != 1) {
                    this.setState({
                        noRooms: this.state.noRooms - 1,
                        // noAdults: (this.state.noRooms - 1) * 2
                    })
                }

                break;
            case 'dAdult':
                if (this.state.noAdults != this.state.noRooms) {
                    this.setState({
                        // noRooms: this.state.noRooms - 1,
                        noAdults: (this.state.noAdults - 1)
                    })
                }
                break;
            case 'iAdult':
                if (this.state.noChild+this.state.noAdults != this.state.noRooms * 4) {
                    this.setState({
                        // noRooms: this.state.noRooms - 1,
                        noAdults: (this.state.noAdults + 1)
                    })
                } else {
                    this.setState({
                        // noRooms: this.state.noRooms + 1,
                        // noAdults: (this.state.noRooms + 1) * 2
                    })
                }
                break;
                case 'dChild':
                    if(this.state.noChild+this.state.noAdults != this.state.noRooms ){
                        if(this.state.noChild !=0){
                            this.setState({
                                noChild: this.state.noChild - 1
                             })
                        }
 
                    }
                    break;
                    case 'iChild':
                        if(this.state.noChild+this.state.noAdults != this.state.noRooms*4 ){
                            this.setState({
                                noChild: this.state.noChild + 1
                             })
                        }


        }

    }

    render() {
        return (
            <Container fluid="true" style={{ height: "100vh" }} className="alignMiddle">
                <Container className="" style={{ height: "80%" }}>
                    <Row className=" alignMiddle" style={{height:"3rem",fontSize:"25px"}} >
                       
                        <FaUserFriends style={{marginRight:"10px", fontSize:"23px"}} />
                     
                        Choose number of <strong className="ml-2">  people</strong>
                         </Row>
                    <Row>
                        <Col md={6} className="d-flex mr-1 border2 flex-row alignMiddle" style={{ borderBottom: "0" }}>
                            <div style={{ width: "10%", height: "3rem", fontSize: "25px" }} className="alignMiddle"><FaBed className="m-auto" /></div>
                            <div style={{ width: "60%", fontSize: "18px", height: "3rem" }} className="alignMiddle">ROOMS</div>
                            <div style={{ width: "30%", height: "3rem" }} className="d-flex h-100 ">
                                <div className="h-100 alignMiddle colorRed" style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                    <div className="text-center w-100 h-100 " >
                                        {this.state.noRooms != 1 ? <FaMinusCircle className=" buttonPressRed" id="dRoom" style={{ hieght: "100%", width: "100%", cursor: 'pointer' }} onClick={this.handleClick} />:
                                        <FaMinusCircle className=" buttonPressRed" id="dRoom" style={{ hieght: "100%", width: "100%", cursor: 'not-allowed', color:"#c99caf" }} /> } 
                                       
                                    </div>

                                </div>
                                <div className="h-100 alignMiddle" style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}><div className="m-auto"> {this.state.noRooms} </div></div>
                                <div className="h-100 alignMiddle" style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                    <div className="text-center w-100 h-100 " >
                                        {this.state.noRooms != 5 ?<FaPlusCircle className="m-auto buttonPressBlue" id="iRoom" onClick={this.handleClick} style={{ hieght: "100%", width: "100%", cursor: 'pointer' }} />:
                                        <FaPlusCircle className="m-auto buttonPressBlue" id="iRoom"  style={{ hieght: "100%", width: "100%", cursor: 'not-allowed',color:"#37465f" }} />
                                        }
                                        
                                    </div>
                                </div>
                            </div>
                       <hr></hr>
                        </Col>
                        <Col md={6} className="d-flex mr-1 border2  flex-row alignMiddle" style={{ borderTop: "0", borderBottom: "0" }}>
                            <div style={{ width: "10%", height: "3rem", fontSize: "20px" }} className="alignMiddle"><FaUserAlt className="m-auto" /></div>
                            <div style={{ width: "60%", fontSize: "18px", height: "3rem" }} className="alignMiddle">ADULTS</div>
                            <div style={{ width: "30%", height: "3rem" }} className="d-flex h-100 ">
                                <div className="h-100 alignMiddle colorRed" style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                    <div className="text-center w-100 h-100 " >
                                        {(this.state.noChild + this.state.noAdults) != this.state.noRooms? 
                                        <FaMinusCircle className="m-auto buttonPressRed" id="dAdult" onClick={this.handleClick} style={{ hieght: "100%", width: "100%", cursor: 'pointer' }} />:
                                        <FaMinusCircle className="m-auto buttonPressRed" style={{ hieght: "100%", width: "100%", cursor: 'not-allowed',color:"#c99caf" }} />
                                        }
                                        
                                    </div>
                                </div>
                                <div className="h-100 alignMiddle" style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}><div className="m-auto">{this.state.noAdults}</div> </div>
                                <div className="h-100 alignMiddle" style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                    <div className="text-center w-100 h-100 " >
                                    {(this.state.noChild + this.state.noAdults) != this.state.noRooms*4? 
                                        <FaPlusCircle className="m-auto buttonPressBlue" id="iAdult" onClick={this.handleClick} style={{ hieght: "100%", width: "100%", cursor: 'pointer' }} />:
                                        <FaPlusCircle className="m-auto buttonPressBlue" style={{ hieght: "100%", width: "100%", cursor: 'not-allowed', color:"#37465f" }} />
                                       }
                                    </div>
                                </div>
                            </div>
                        </Col>
                        <Col md={6} className="d-flex border2 flex-row alignMiddle" style={{ borderTop: "0" }}>
                            <div style={{ width: "10%", height: "3rem", fontSize: "20px" }} className="alignMiddle"><FaChild className="m-auto" /></div>
                            <div style={{ width: "60%", fontSize: "18px", height: "3rem" }} className="alignMiddle">CHILDREN</div>
                            <div style={{ width: "30%", height: "3rem" }} className="d-flex h-100 ">
                                <div className="h-100 alignMiddle colorRed"  style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                <div className="text-center w-100 h-100 " >
                                 {(this.state.noChild + this.state.noAdults) != this.state.noRooms? 
                                    <FaMinusCircle className="m-auto buttonPressRed" id="dChild" onClick={this.handleClick} style={{ hieght: "100%", width: "100%", cursor: 'pointer' }} />:
                                    <FaMinusCircle className="m-auto buttonPressRed"  style={{ hieght: "100%", width: "100%", cursor: 'not-allowed',color:"#c99caf" }} />
                                    }
                                </div>
                                </div>
                                <div className="h-100 alignMiddle " style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                    <div className="m-auto">{this.state.noChild} </div>
                                </div>
                                <div className="h-100 alignMiddle"  style={{ width: "33.3%", fontSize: "28px", height: "3rem" }}>
                                <div className="text-center w-100 h-100 " >
                                {(this.state.noChild + this.state.noAdults) != this.state.noRooms*4? <FaPlusCircle className="m-auto buttonPressBlue" id="iChild" onClick={this.handleClick} style={{ hieght: "100%", width: "100%", cursor: 'pointer' }} /> :
                             <FaPlusCircle className="m-auto " style={{ hieght: "100%", width: "100%", cursor: 'not-allowed', color:"#37465f"}} />
                               
                                    }
                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </Container>
        )
    }
}
